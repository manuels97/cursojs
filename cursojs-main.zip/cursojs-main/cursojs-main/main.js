const textCalorias= document.getElementById("calorias")
const botonAgregar=document.getElementById("sumarcal")
const contador= document.getElementById("contadore")
const contadorTotal= document.getElementById("total");
const textObjetivo=document.getElementById("objetivo")
const botonObjetivo=document.getElementById("btn-obj")
const restantes= document.getElementById("restantes")
const textQuemadas=document.getElementById("quemadas")
const botonQuemadas=document.getElementById("btn-quemadas")
const kquemadas=document.getElementById("kquemadas")
let restantes1= textObjetivo.value;
let quemadas1=textQuemadas.value;
let caloriasTotal=0;
parseInt(textCalorias)
parseInt(caloriasTotal)


botonObjetivo.addEventListener("click",(e) =>{
    e.preventDefault();
    
    restantes.innerHTML=`
                        <div>
                        <h1> Tu objetivo son ${textObjetivo.value}
                        Te faltan consumir ${restantes1}</h1>
                        
                        </div>
                        `

})


botonQuemadas.addEventListener("click", (e)=>{
    e.preventDefault()

    kquemadas.innerHTML=`
                            <div>
                            <h1> El dia de hoy quemaste: ${quemadas1}</h1>
                            
                            </div>
                            `



})

botonAgregar.addEventListener("click", (e)=> {
    e.preventDefault()
    iniciar()
    
})

const iniciar =()=> {
    
    let calorias=0; 
    parseInt(calorias)
    
    calorias= textCalorias.value ;
    caloriasTotal= caloriasTotal+calorias; 
    restantes1-= calorias
    contador.innerHTML=`
                    <div>
                    <h1>Consumidas</h1>
                    <h2 >${calorias} </h2>
                    </div>
                    `


    contadorTotal.innerHTML=`
                        <div>
                        <h1>TOTAL</h1>
                        <h2 >${caloriasTotal} </h2>
                        </div>
                        `          
                        
                        
    restantes.innerHTML=`
                        <div>
                        <h1> Tu objetivo son ${textObjetivo.value}
                        Te faltan consumir ${restantes1}</h1>
                        
                        </div>
                        `
}


